"""
properties.py

Blender Property Groups for the Leather Mold Generator.
"""

import bpy
from bpy.types import PropertyGroup
from bpy.props import FloatProperty, PointerProperty


class LeatherMoldProperties(PropertyGroup):
    """Settings used by the Leather Mold Generator."""

    leather_thickness: FloatProperty(
        name="Leather Thickness",
        description="Thickness of the leather in millimeters",
        default=2.0,
        min=0.5,
        max=10.0,
        precision=2,
        unit='LENGTH',
    )

    clearance: FloatProperty(
        name="Clearance",
        description="Additional clearance between the mold and leather",
        default=0.5,
        min=0.0,
        max=5.0,
        precision=2,
        unit='LENGTH',
    )

    block_width: FloatProperty(
        name="Block Width",
        description="Width of the mold block",
        default=120.0,
        min=20.0,
        unit='LENGTH',
    )

    block_depth: FloatProperty(
        name="Block Depth",
        description="Depth of the mold block",
        default=120.0,
        min=20.0,
        unit='LENGTH',
    )

    block_height: FloatProperty(
        name="Block Height",
        description="Height of the mold block",
        default=30.0,
        min=10.0,
        unit='LENGTH',
    )


def register():
    """Register Blender properties."""

    bpy.utils.register_class(LeatherMoldProperties)

    bpy.types.Scene.leather_mold = PointerProperty(
        type=LeatherMoldProperties
    )


def unregister():
    """Unregister Blender properties."""

    del bpy.types.Scene.leather_mold

    bpy.utils.unregister_class(LeatherMoldProperties)